"""
SHL Product Catalog Scraper
Scrapes Individual Test Solutions from https://www.shl.com/solutions/products/product-catalog/
Saves structured data to data/catalog.json
"""
import requests
from bs4 import BeautifulSoup
import json
import time
import re
from urllib.parse import urljoin

BASE_URL = "https://www.shl.com"
CATALOG_URL = "https://www.shl.com/solutions/products/product-catalog/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}

# SHL test type codes
TEST_TYPE_MAP = {
    "A": "Ability & Aptitude",
    "B": "Biodata & Situational Judgement",
    "C": "Competencies",
    "D": "Development & 360",
    "E": "Assessment Exercises",
    "K": "Knowledge & Skills",
    "M": "Motivation",
    "P": "Personality & Behaviour",
    "S": "Simulations",
}


def get_test_type_code(type_str: str) -> str:
    """Map test type string to single-letter code."""
    type_str = type_str.strip().upper()
    for code, name in TEST_TYPE_MAP.items():
        if code in type_str or name.lower() in type_str.lower():
            return code
    return "K"  # default to Knowledge


def scrape_catalog():
    products = []
    page = 1
    per_page = 12  # SHL default

    print("Starting SHL catalog scrape...")

    while True:
        url = f"{CATALOG_URL}?type=1&start={((page-1)*per_page)}&sz={per_page}"
        print(f"Fetching page {page}: {url}")

        try:
            resp = requests.get(url, headers=HEADERS, timeout=30)
            resp.raise_for_status()
        except Exception as e:
            print(f"Error fetching page {page}: {e}")
            break

        soup = BeautifulSoup(resp.text, "html.parser")

        # Find product rows/cards
        rows = soup.select("tr.product-catalogue__row") or soup.select(".product-catalogue__row")
        
        if not rows:
            # Try alternative selectors
            rows = soup.select("[class*='catalogue']") or soup.select(".js-target-company")
        
        if not rows:
            print(f"No products found on page {page}, stopping.")
            break

        page_count = 0
        for row in rows:
            try:
                # Name and URL
                name_el = row.select_one("a") or row.select_one(".product-catalogue__title")
                if not name_el:
                    continue
                name = name_el.get_text(strip=True)
                href = name_el.get("href", "")
                if href and not href.startswith("http"):
                    href = urljoin(BASE_URL, href)

                # Test types (look for type indicators)
                test_types = []
                type_els = row.select("[class*='type']") or row.select(".product-catalogue__type")
                for el in type_els:
                    txt = el.get_text(strip=True)
                    if txt:
                        test_types.append(txt)

                # Remote testing and adaptive flags
                remote_el = row.select_one("[class*='remote']")
                adaptive_el = row.select_one("[class*='adaptive']")
                
                remote = "Yes" if remote_el and "yes" in remote_el.get_text(strip=True).lower() else "No"
                adaptive = "Yes" if adaptive_el and "yes" in adaptive_el.get_text(strip=True).lower() else "No"

                # Description if available
                desc_el = row.select_one("[class*='desc']") or row.select_one("p")
                description = desc_el.get_text(strip=True) if desc_el else ""

                product = {
                    "name": name,
                    "url": href,
                    "test_types": test_types if test_types else ["K"],
                    "remote_testing": remote,
                    "adaptive_irt": adaptive,
                    "description": description,
                }
                products.append(product)
                page_count += 1
                print(f"  Found: {name}")

            except Exception as e:
                print(f"  Error parsing row: {e}")
                continue

        print(f"  Page {page}: {page_count} products")

        if page_count < per_page:
            break

        page += 1
        time.sleep(1)

    print(f"\nTotal products scraped: {len(products)}")
    return products


def scrape_product_detail(url: str) -> dict:
    """Scrape individual product page for more details."""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=20)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        detail = {}

        # Description
        desc = soup.select_one(".hero__description") or soup.select_one("[class*='description']")
        if desc:
            detail["description"] = desc.get_text(strip=True)

        # Duration
        for el in soup.find_all(string=re.compile(r"\d+\s*min", re.I)):
            detail["duration"] = el.strip()
            break

        # Languages
        lang_el = soup.find(string=re.compile(r"language", re.I))
        if lang_el and lang_el.parent:
            detail["languages"] = lang_el.parent.get_text(strip=True)

        return detail
    except Exception:
        return {}


def main():
    products = scrape_catalog()

    # Optionally enrich with detail pages (slow, use sparingly)
    # for p in products[:5]:
    #     if p["url"]:
    #         detail = scrape_product_detail(p["url"])
    #         p.update(detail)
    #         time.sleep(0.5)

    out_path = "/home/claude/shl-agent/data/catalog.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"products": products, "total": len(products)}, f, indent=2, ensure_ascii=False)

    print(f"\nSaved {len(products)} products to {out_path}")


if __name__ == "__main__":
    main()
